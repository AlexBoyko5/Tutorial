import { Container, Heading, Section } from 'components';

export const Home = () => {
  return (
    <Section>
      <Container>
        <Heading title="Home" bottom />
      </Container>
    </Section>
  );
};
