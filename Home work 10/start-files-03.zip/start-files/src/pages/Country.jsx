import { Container, Heading, Section } from 'components';

export const Country = () => {
  return (
    <Section>
      <Container>
        <Heading title="SearchCountry" bottom />
      </Container>
    </Section>
  );
};
