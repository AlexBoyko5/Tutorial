import { Heading } from 'components';

export const App = () => {
  return <Heading title="App" bottom />;
};
