export const CountryList = () => {
  return <h2>CountryList</h2>;
};
